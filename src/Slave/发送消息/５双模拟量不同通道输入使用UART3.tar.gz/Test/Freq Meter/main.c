#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/adc.h"

#define Baud_Rate 115200
#define STOP_BIT '\n'

bool Vflag;
bool Aflag;

volatile uint32_t Analog_Voltage_pui32ADC0Value[8], Analog_Voltage_Sum;
volatile unsigned int Analog_Voltage;
volatile unsigned char M_to_L_Bit_of_Analog_Voltage[5];

volatile uint32_t Current_pui32ADC0Value[8], Current_Sum;
volatile unsigned int Current;
volatile unsigned char M_to_L_Bit_of_Current[5];

void UART3IntHandler(void)
{
    unsigned int status = UARTIntStatus(UART3_BASE, true);
    UARTIntClear(UART3_BASE, status);
    while (UARTCharsAvail(UART3_BASE))
        UARTCharPutNonBlocking(UART3_BASE, UARTCharGetNonBlocking(UART3_BASE));
}
void ADC0Sequence0Handler(void)
{
    uint16_t i;
    ADCIntClear(ADC0_BASE, 0);
    ADCSequenceDataGet(ADC0_BASE, 0, Analog_Voltage_pui32ADC0Value);
    for(i = 0; i < 8;i ++){
        Analog_Voltage_Sum = Analog_Voltage_Sum + (Analog_Voltage_pui32ADC0Value[i] * 3300 / 4096);
    }
    Vflag=1;
}
void ADC1Sequence0Handler(void)
{
    uint16_t i;
    ADCIntClear(ADC1_BASE, 0);
    ADCSequenceDataGet(ADC1_BASE, 0, Current_pui32ADC0Value);
    for(i = 0; i < 8;i ++){
        Current_Sum = Current_Sum + (Current_pui32ADC0Value[i] * 3300 / 4096);
    }
    Aflag=1;
}
void ConfigUART3(uint32_t BaudRate){

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);//A0, A1 for RX & TX

    GPIOPinConfigure(GPIO_PC6_U3RX);
    GPIOPinConfigure(GPIO_PC7_U3TX);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_6 | GPIO_PIN_7);

    UARTConfigSetExpClk(UART3_BASE, SysCtlClockGet(), BaudRate, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE)); //8个数据位，1个停止位， 无校验位
}
void ConfigUART3Interrupt(void (*UART3IntHandler)(void)){

    IntEnable(INT_UART3);
    UARTIntEnable(UART3_BASE, UART_INT_RX | UART_INT_RT);
    UARTIntRegister(UART3_BASE, UART3IntHandler);
}
void Data_Break(unsigned int Analog_Voltage, unsigned int Current, unsigned char M_to_L_Bit_of_Analog_Voltage[], unsigned char M_to_L_Bit_of_Current[]){
    //13925
    M_to_L_Bit_of_Analog_Voltage[0] = Analog_Voltage / 10000 + '0';       //1
    M_to_L_Bit_of_Analog_Voltage[1] = (Analog_Voltage / 1000) % 10 + '0'; //3
    M_to_L_Bit_of_Analog_Voltage[2] = (Analog_Voltage / 100) % 10 + '0';  //9
    M_to_L_Bit_of_Analog_Voltage[3] = (Analog_Voltage / 10) % 10 + '0';   //2
    M_to_L_Bit_of_Analog_Voltage[4] = Analog_Voltage % 10 + '0';          //5


    //Current
    M_to_L_Bit_of_Current[0] = Current / 10000 + '0';       //1
    M_to_L_Bit_of_Current[1] = (Current / 1000) % 10 + '0'; //3
    M_to_L_Bit_of_Current[2] = (Current / 100) % 10 + '0';  //9
    M_to_L_Bit_of_Current[3] = (Current / 10) % 10 + '0';   //2
    M_to_L_Bit_of_Current[4] = Current % 10 + '0';          //5

}
void Sent_Voltage(uint32_t ui32Base, unsigned char M_to_L_Bit_of_Analog_Voltage[]){
    short index = 0;
    for(index = 0; index < 5; index++){
        while(UARTBusy(ui32Base));
        UARTCharPut(ui32Base, M_to_L_Bit_of_Analog_Voltage[index]);
        while(UARTBusy(ui32Base));
    }
    UARTCharPut(ui32Base, STOP_BIT);
}
void ConfigADC0(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_1);
    ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);
    // PE1: AIN2
    ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 1, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 2, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 3, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 4, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 5, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 6, ADC_CTL_CH2 );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 7, ADC_CTL_CH2 | ADC_CTL_IE | ADC_CTL_END);
    ADCSequenceEnable(ADC0_BASE, 0);

}
void ConfigADC1(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0);
    ADCSequenceConfigure(ADC1_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);
    // PE0: AIN3
    ADCSequenceStepConfigure(ADC1_BASE, 0, 0, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 1, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 2, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 3, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 4, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 5, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 6, ADC_CTL_CH3 );
    ADCSequenceStepConfigure(ADC1_BASE, 0, 7, ADC_CTL_CH3 | ADC_CTL_IE | ADC_CTL_END);
    ADCSequenceEnable(ADC1_BASE, 0);
}
void ConfigADC0Interrupt(){
    ADCIntRegister(ADC0_BASE, 0, ADC0Sequence0Handler);
    ADCIntEnable(ADC0_BASE, 0);
    IntEnable(INT_ADC0SS0);
}
void ConfigADC1Interrupt(){
    ADCIntRegister(ADC1_BASE, 0, ADC1Sequence0Handler);
    ADCIntEnable(ADC1_BASE, 0);
    IntEnable(INT_ADC1SS0);
}
void StartAllInterrupt(){
    IntMasterEnable();
}
void main(void)
{

    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);
    ConfigUART3(Baud_Rate);

    ConfigADC0();
    ConfigADC0Interrupt();
    ConfigADC1();
    ConfigADC1Interrupt();

    StartAllInterrupt();
    PortFunctionInit();
    lcd_init();
    lcd_printf(4, 0, "EM Meter");
    lcd_printf(9, 2, "mV");
    lcd_printf(9, 3, "mV/A");
    while (1)
    {
        ADCIntClear(ADC0_BASE, 0);
        ADCIntClear(ADC1_BASE, 0);
        ADCProcessorTrigger(ADC0_BASE, 0);
        ADCProcessorTrigger(ADC1_BASE, 0);
        if(Vflag == 1){
            Analog_Voltage = Analog_Voltage_Sum / 8;
            Analog_Voltage_Sum = 0;
            Vflag = 0;
        }
        if(Aflag == 1){
            Current = Current_Sum / 8;
            Current_Sum = 0;
            Aflag = 0;
        }
        Data_Break(Analog_Voltage, Current, M_to_L_Bit_of_Analog_Voltage, M_to_L_Bit_of_Current);
        Sent_Voltage(UART3_BASE, M_to_L_Bit_of_Analog_Voltage);
        lcd_printf(3, 2, M_to_L_Bit_of_Analog_Voltage);
        lcd_printf(3, 3, M_to_L_Bit_of_Current);
        SysCtlDelay(SysCtlClockGet() / 30);


    }

}
