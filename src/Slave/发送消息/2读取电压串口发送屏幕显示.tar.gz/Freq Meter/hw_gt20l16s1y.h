
#ifndef __HW_GT20L16S1Y_H__
#define __HW_GT20L16S1Y_H__

#define GT20_READ           0x03
#define GT20_FAST_READ      0x11

#endif // __HW_GT20L16S1Y_H__
